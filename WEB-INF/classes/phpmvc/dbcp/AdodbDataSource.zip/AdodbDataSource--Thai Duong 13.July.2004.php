<?php
/*
* $Header: /cavatxanh/cavatxanh/malis/middleware/phpmvc-base-0.3.4/WEB-INF/classes/phpmvc/dbcp/AdodbDataSource.php,v 1.2 2004/04/15 16:00:05 thai Exp $
* $Revision: 1.2 $
* $Date: 2004/04/15 16:00:05 $
*
*/


include_once 'lib/adodb/adodb.inc.php';
$ADODB_FETCH_MODE = ADODB_FETCH_ASSOC;


class AdodbDataSource {//extends ADOConnection{

	// ----- Properties ----------------------------------------------------- //
		var $dsn = '';
        var $databaseType = '';         /// RDBMS currently in use, eg. odbc, mysql, mssql       
        var $database = '';                     /// Name of database to be used.
        var $host = '';                         /// The hostname of the database server
        var $user = '';                         /// The username which is used to connect to the database server.
        var $password = '';             /// Password for the username. For security, we no longer store it.
		var $conn='';
		var $affect_row = false;
		var $count = false;
		var $insert_id = false;		
	// Setters. ( set[PropertyToSet]($value) )
	// <set-property property = "username"   value = "xxxxxxxx"/>

	function setDsn($value)	{
		$this->dsn = $value;		
	}

	function setDatabaseType($value) {
		$this->databaseType = $value;
	}
	function setDatabase($value) {
		$this->database = $value;
	}
	function setHost($value) {
		$this->host = $value;
	}
	function setUser($value) {
		$this->user = $value;
	}
	function setPassword($value) {
		$this->password = $value;
	}

// ----- Public Methods ---------------------------------------------------- //

	/**
	* Setup the database server connection.
	*<p>Returns immediately if a connection already exists.
	*<p>Note: It is assumed that this object has been pre-configured via the
	* initialisation process.
	*
	* @returns void
	*/
	function open() {
		$this->conn = & ADONewConnection($this->databaseType);
		//$this->conn->PConnect($this->dsn,$this->user,$this->password);	
		$this->conn->PConnect($this->host,$this->user,$this->password,$this->database);
		
	}
	function Execute(&$sql){
		
		$rs =& $this->conn->Execute($sql);
		
		return $rs;
	}	

	function ErrorMsg(){
		$errorMsg =& $this->conn->ErrorMsg();
		return $errorMsg;
		
	}

	function Insert_ID(){
		$id =& $this->conn->Insert_ID();
		return $id;	
	}
	
	//chu' y' function na`y
	function nextId($seqName = 'adodbseq',$startID=1) {
		$id =& $this->conn->GenID($seqName, $startID);
		return $id;	

	}

	function Close() {
		$this->conn->close();
		$this->conn = NULL;
	}

	function GetRow(&$sql) {
		$rs =& $this->conn->GetRow($sql);
		return $rs;
	}
	

	function quote($s) {
		$s =& $this->conn->quote($s);
		return $s;
	}

	function GetOne(&$sql) {
		$rs = & $this->conn->GetOne($sql);
		return $rs;
	}

	function GetAll(&$sql) {
		$rs = & $this->conn->GetAll($sql);
		return $rs;
	
	}

	function GetCol(&$sql) {
		$rs =& $this->conn->GetCol($sql);
		return $rs;
	}

	function qstr(&$str,$magic_quotes_enabled=false) {
		$str=& $this->conn->qstr($str,$magic_quotes_enabled);
		return $str;
	}
	

	function setfetchmode($mode) {
		$res =& $this->conn->SetFetchMode($mode);
		return $res;
	}
	

	function SelectLimit($sql,$numrows=-1,$offset=-1,$inputarr=false) {
		$res =& $this->conn->SelectLimit($sql,$numrows,$offset,$inputarr);
		return $res;
	
	}
	


	function getRsArray(&$sql, $type='section') {
		$rs = &$this->conn->Execute($sql);
		if(is_object($rs)) {
			$this->affect_row = false;
			$this->count = $rs->RecordCount();
			$this->insert_id = false;
			if($this->count != 0) {
				//$i=0;
				while($row = $rs->FetchRow()) {
					foreach($row as $key => $value) {
						if(!is_numeric($key)) {
							if($type == "section") {
								$result[$key][] = $value;
								//$result[$key][$i] = $value;
							} elseif($type == "normal") {
								($this->count > 1) ? $result[$key][] = $value : $result[$key] = $value;
							}
						}
					}
					//$i++;
				}
				$rs->Close();
	        	return $result; 
			} else {
				$rs->Close();
				return false;
			}
		} else {
			$this->affect_row = false;
			$this->count = false;
			$this->insert_id = false;
			return false;
		}
	}	
}
?>
