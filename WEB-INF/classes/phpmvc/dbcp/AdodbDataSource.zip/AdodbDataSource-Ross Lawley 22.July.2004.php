<?php
/*
* $Header: /PHPMVC/phpmvc-base/WEB-INF/classes/phpmvc/dbcp/AdodbDataSource.php,v 1.2 2003/12/30 23:53:48 who Exp $
* $Revision: 1.2 $
* $Date: 2003/12/30 23:53:48 $
*
* ====================================================================
*
* License:	GNU Lesser General Public License (LGPL)
*
* Copyright (c) 2003 Eric Chang.  All rights reserved.
*
* This file is part of the php.MVC Web applications framework
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.

* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.

* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


/*  A class that provides an interface to the ADODB database abstraction classes(with mysql).
*
* Adapted by Ross Lawley
*
* @author Eric Chang
* @email scrazy@downput.com
* @version 2003
* @public
*/

include_once '/usr/local/lib/adodb/drivers/adodb-mysqlt.inc.php';
include_once '/usr/local/lib/adodb/adodb.inc.php';

class AdodbDataSource extends adodb_mysqlt{
	// ----- Properties ----------------------------------------------------- //
	var $rsPrefix = 'hack_rs';
        var $databaseType = '';         /// RDBMS currently in use, eg. odbc, mysql, mssql
        var $database = '';             /// Name of database to be used.
        var $host = '';                 /// The hostname of the database server
        var $username = '';                 /// The username which is used to connect to the database server.
        var $password = '';             /// Password for the username. For security, we no longer store it.
	// Setters. ( set[PropertyToSet]($value) )
	// <set-property property = "username"   value = "xxxxxxxx"/>

	function setDatabaseType($value) {
		$this->databaseType = $value;
	}
	function setDatabase($value) {
		$this->database = $value;
	}
	function setHost($value) {
		$this->host = $value;
	}
	function setUsername($value) {
		$this->username = $value;
	}
	function setPassword($value) {
		$this->password = $value;
	}

// ----- Public Methods ---------------------------------------------------- //

	/**
	* Setup the database server connection.
	*<p>Returns immediately if a connection already exists.
	*<p>Note: It is assumed that this object has been pre-configured via the
	* initialisation process.
	*
	* @returns void
	*/
	function open() {
		$this->PConnect($this->host,$this->username,$this->password,$this->database);
	}
}
class hack_rsmysql extends ADORecordSet_mysqlt {
 /* record set modify place here*/
}
$ADODB_NEWCONNECTION = 'hack_factory';
function& hack_factory()
{
	$obj = new AdodbDataSource();
	return $obj;
}

?>
